import{s as G,k as U,a as y,j as s,e as k,t as R}from"./index-B-nEeYD9.js";import{P as v}from"./Page-Dmru9nHk.js";import{C as z}from"./Select-BVbaq4tV.js";import{B as P}from"./index-2tE0_P8l.js";import"./clsx-B-dksMZM.js";import"./react-select.esm-BESMukCw.js";import"./defineProperty-BAgxAJIZ.js";import"./slicedToArray-Dby63wcm.js";import"./floating-ui.dom-Dx_LP4Vq.js";function et(){const N=G(),[S]=U(),m=S.get("hakuna"),[T,$]=y.useState(!0),[h,I]=y.useState(null),[O,_]=y.useState(null);y.useEffect(()=>{(async()=>{if(!m){_("Purchase Order ID is required"),$(!1);return}try{$(!0),_(null);const o=await k.get(`/inventory/view-purchase-order/${m}`);if(!o.data.status||!o.data.data)throw new Error(o.data.message||"Purchase Order not found");const{purchase_order:e,supplier_details:a,items:g=[],summary:n={}}=o.data.data;let u={};try{const i=await k.get("get-company-info");if(i.data.status&&i.data.data){const c=i.data.data;u={name:c.company.name,logo:c.branding.logo,gstno:c.company.gst_no,panno:c.company.pan_no,cin_no:c.company.cin_no,address:c.address,contact:c.contact}}}catch(i){console.warn("Failed to fetch company info:",i)}const r={};g.forEach(i=>{const c=i.tax_rate??"0",f=parseFloat(String(c).replace(/[\s%]/g,""))||0,j=String(f),q=parseFloat(i.price||i.list_price||0),M=parseFloat(i.quantity||0),B=parseFloat(i.taxableamount||i.amount||q*M||0)*f/100;r[j]=(r[j]||0)+B});const l=parseFloat(e.packaginchrgs||e.packing_charges||n.packing_charges||0)+parseFloat(e.freightchrgs||e.freight_charges||n.freight_charges||0)+parseFloat(e.insurancechrgs||e.insurance_charges||n.insurance_charges||0)+parseFloat(e.calibrationchrgs||e.calibration_charges||n.calibration_charges||0)+parseFloat(e.trainingchrgs||e.training_charges||n.training_charges||0),p=l*18/100;r[18]=(r[18]||0)+p;const d=u.gstno?u.gstno.substring(0,2):"",F=(a.gst_number||a.gstno||"").substring(0,2),x=a.gst_state_code||a.statecode||F||"",A=x==="23"||d&&x===d;let C=a.state||a.statename||"";try{if(!C&&x){const i=await k.get("/people/get-state");if(i.data&&i.data.data){const c=i.data.data.find(f=>parseInt(f.gst_code)===parseInt(x)||parseInt(f.id)===parseInt(x));c&&(C=c.state)}}}catch(i){console.warn("Failed to fetch states:",i)}I({purchaseOrder:{...e,quotationno:e.quotationno||e.quotation_no,quotationdate:e.quotationdate||e.quotation_date,otherdetails:e.otherdetails||e.other_details,discount:e.discount||n.discount,totalafterdisc:e.totalafterdisc||n.total_after_discount,packaginchrgs:e.packaginchrgs||e.packing_charges||n.packing_charges,freightchrgs:e.freightchrgs||e.freight_charges||n.freight_charges,insurancechrgs:e.insurancechrgs||e.insurance_charges||n.insurance_charges,calibrationchrgs:e.calibrationchrgs||e.calibration_charges||n.calibration_charges,trainingchrgs:e.trainingchrgs||e.training_charges||n.training_charges,customdutychrgs:e.customdutychrgs||e.custom_duty_charges||n.custom_duty_charges,total_amount:e.total_amount||n.total_invoice_amount,roundoff:e.roundoff||n.roundoff,finaltotal:e.finaltotal||n.final_total,digitalsignUrl:e.digitalsignUrl||n.digitalsignUrl},customer:{...a,gstno:a.gst_number||a.gstno,panno:a.pan_number||a.pan_no||(a.gst_number||a.gstno||"").slice(2,12),address:a.full_address||a.address,stateName:C},items:g,company:u,combineTax:r,isSameState:A,stateCode:x?String(x).padStart(2,"0"):"",miscCharges:l,gstOnCharges:p})}catch(o){console.error("Error fetching PDF data:",o),_(o.message||"Failed to load PDF data")}finally{$(!1)}})()},[m]);const w=t=>t?new Date(t).toLocaleDateString("en-GB"):"",E=t=>{if(t=Math.floor(Math.abs(Number(t)||0)),t===0)return"zero";const o=["","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"],e=["","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"],a=d=>d===0?"":d<20?o[d]:e[Math.floor(d/10)]+(d%10?" "+o[d%10]:""),g=d=>{if(d===0)return"";const b=Math.floor(d/100),F=d%100;return(b?o[b]+" hundred ":"")+a(F)},n=Math.floor(t/1e7);t%=1e7;const u=Math.floor(t/1e5);t%=1e5;const r=Math.floor(t/1e3);t%=1e3;const l=t;let p="";return n&&(p+=g(n)+" crore "),u&&(p+=g(u)+" lakh "),r&&(p+=g(r)+" thousand "),l&&(p+=g(l)),p.trim().replace(/\s+/g," ")},D=()=>{if(!h)return"";const{purchaseOrder:t,customer:o,items:e,company:a,combineTax:g,isSameState:n,stateCode:u}=h;return`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style>
          body {
            margin: 0px !important;
            padding: 0px !important;
            font-size: 11px;
            font-family: Arial, sans-serif;
          }
          
          .table {
            width: 100%;
            border-collapse: collapse;
          }
          
          .table-borderless > tbody > tr > td,
          .table-borderless > tbody > tr > th,
          .table-borderless > tfoot > tr > td,
          .table-borderless > tfoot > tr > th,
          .table-borderless > thead > tr > td,
          .table-borderless > thead > tr > th {
            border: none;
            vertical-align: top;
          }
          
          table.table-bordered {
            border: 1px solid black;
            margin-top: 20px;
            border-collapse: collapse;
          }
          
          table.table-bordered > thead > tr > th {
            border: 1px solid black;
            vertical-align: top;
          }
          
          table.table-bordered > tbody > tr > td {
            border: 1px solid black;
            vertical-align: top;
          }
          
          .text-right {
            text-align: right;
          }
          
          .text-left {
            text-align: left;
          }
          
          .text-center {
            text-align: center;
          }
          
          ${t.status===-1?`
            body {
              background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='200' height='200' viewBox='0 0 200 200'><text x='50%' y='50%' font-size='40' fill='rgba(200,200,200,0.5)' text-anchor='middle' transform='rotate(-45 100 100)'>DRAFT</text></svg>");
              background-repeat: no-repeat;
              background-position: center;
            }
          `:""}
        </style>
      </head>
      <body>
        <!-- Company Header -->
        <div style="display: flex; flex-direction: column; align-items: center; margin-bottom: 8px; gap: 4px;">
          <div style="display: flex; align-items: flex-start; gap: 12px; width: 100%;">
            ${a.logo?`<img src="${a.logo}" alt="Logo" style="height: 60px; width: auto;" />`:""}
            <div style="flex: 1; text-align: right;">
              <p style="font-family: monospace; font-size: 10px; font-style: italic; color: #555; margin: 0;">
                NABL Accredited as per IS/ISO/IEC 17025 (Certificate Nos. TC-7832 &amp; CC-2348),<br>
                BIS Recognized &amp; ISO 9001 Certified Test &amp; Calibration Laboratory
              </p>
            </div>
          </div>
          <div style="font-size: 20px; font-weight: bold; color: navy; text-align: left; margin-top: 4px;">
            ${a.name}
          </div>
        </div>

        <div style="text-align: center; margin-bottom: 8px; margin-top: 20px;">
          <div style="font-size: 14px; font-weight: bold; text-transform: uppercase;">
            <b>${t.ordertype==="WO"?"Work Order":"Purchase Order"}</b>
          </div>
        </div>

        <!-- Customer Information -->
        <table class="table table-bordered">
          <tr>
            <td colspan="2" style="width: 70%">
              <b>Customer:<br></b>
              <div style="float: left;width:13%"><b>M / s . :</b></div>
              <div style="float: left;width:87%">
                <b>${o.company||""}</b><br>
                ${o.address||""}<br>
                
                <table class="table table-borderless">
                  <tr>
                    <td style="width:50%;">
                      <b>State name : </b>${o.stateName||o.state||""}<br>
                      <b>GSTIN/UIN : </b>${o.gstno||""}
                    </td>
                    <td style="width:50%;">
                      <b>State code : </b>${u}<br>
                      <b>PAN: </b>${o.panno||""}
                    </td>
                  </tr>
                </table>
              </div>
              <div style="clear:both;"></div>
              Kind Attn. ${t.sname||o.contact_person||""}
            </td>
            <td style="width: 30%;">
              <b>${t.ordertype==="WO"?"Work Order":"Purchase Order"} No. : </b> ${t.po_number||""}<br>
              <b>Date : </b>${w(t.date)}<br>
              <b>Quotation No./ Date : </b> ${t.quotationno||""} ${w(t.quotationdate)}<br>
            </td>
          </tr>
        </table>

        <!-- Items Table -->
        <table class="table table-condensed table-bordered table-striped">
          <thead>
            <tr>
              <th class="text-center" style="width:10%">S. No.</th>
              <th class="text-center" style="width:50%"><b>Particular</b></th>
              <th class="text-center" style="width:50%"><b>Specification</b></th>
              <th class="text-center"><b>${t.ordertype==="PO"?"HSN Code":"SAC Code"}</b></th>
              <th class="text-center"><b>Unit (QTY)</b></th>
              <th class="text-center"><b>Amount</b></th>
            </tr>
          </thead>
          <tbody>
            ${e.map((r,l)=>`
              <tr>
                <td class="text-center">${l+1}</td>
                <td>
                  ${t.ordertype==="PO"?r.material_name||r.category_name||r.itemname||"":r.itemname||r.material_name||""}
                  ${r.specification&&r.specification.trim().toUpperCase()!=="NA"?"<br>"+r.specification:""}
                </td>
                <td class="text-center">${r.specification||""}</td>
                <td class="text-center">${r.hsn_code||""}</td>
                <td class="text-center">
                  ${t.ordertype==="PO"?`${r.quantity||""} ${r.unit_name||r.unit||""}`:`${r.quantity||""} No's`}
                </td>
                <td class="text-right" style="padding-right: 8px;">
                  ${parseFloat(r.price||r.list_price||0).toFixed(2)}
                </td>
              </tr>
            `).join("")}
          </tbody>
          
          <!-- Charges and Taxes -->
          ${t.discount?`
            <tr>
              <td colspan="2">Discount (${t.discount}%)</td>
              <td colspan="4" class="text-right">${parseFloat(t.discount||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          ${t.totalafterdisc?`
            <tr>
              <td colspan="2">Total After Discount Value</td>
              <td colspan="4" class="text-right">${parseFloat(t.totalafterdisc||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          ${t.packaginchrgs?`
            <tr>
              <td colspan="2">Packing & Forwarding Charges</td>
              <td colspan="4" class="text-right">${parseFloat(t.packaginchrgs||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          ${t.freightchrgs?`
            <tr>
              <td colspan="2">Freight Charges</td>
              <td colspan="4" class="text-right">${parseFloat(t.freightchrgs||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          ${t.insurancechrgs?`
            <tr>
              <td colspan="2">Insurance charges</td>
              <td colspan="4" class="text-right">${parseFloat(t.insurancechrgs||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          ${t.calibrationchrgs?`
            <tr>
              <td colspan="2">Calibration Certificate Charges</td>
              <td colspan="4" class="text-right">${parseFloat(t.calibrationchrgs||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          <tr>
            <td colspan="2">Installation,Demonstration&Training Charges</td>
            <td colspan="4" class="text-right">${parseFloat(t.trainingchrgs||0).toFixed(2)}</td>
          </tr>
          
          ${t.customdutychrgs?`
            <tr>
              <td colspan="2">Import /Custom Duty Charges</td>
              <td colspan="4" class="text-right">${parseFloat(t.customdutychrgs||0).toFixed(2)}</td>
            </tr>
          `:""}
          
          <!-- Tax Breakdown -->
          ${Object.entries(g).filter(([,r])=>r>0).map(([r,l])=>{if(n){const p=l/2,d=l/2,b=parseFloat(r)/2;return`
                <tr>
                  <td colspan="2"><strong>CGST ${b}%</strong></td>
                  <td colspan="4" class="text-right">${p.toFixed(2)}/-</td>
                </tr>
                <tr>
                  <td colspan="2"><strong>SGST ${b}%</strong></td>
                  <td colspan="4" class="text-right">${d.toFixed(2)}/-</td>
                </tr>
              `}else return`
                <tr>
                  <td colspan="2"><strong>IGST ${r}%</strong></td>
                  <td colspan="4" class="text-right">${l.toFixed(2)}/-</td>
                </tr>
              `}).join("")}
          
          <tr>
            <td colspan="2">Total Charges With tax</td>
            <td colspan="4" class="text-right">${parseFloat(t.total_amount||0).toFixed(2)}</td>
          </tr>
          
          <tr>
            <td colspan="2">Round off</td>
            <td colspan="4" class="text-right">${parseFloat(t.roundoff||0).toFixed(2)}</td>
          </tr>
          
          <tr>
            <td colspan="2" style="border-right: 0px transparent;">
              (IN WORDS): Rs. ${E(Math.round(t.finaltotal||0)).toUpperCase()} Only
            </td>
            <td colspan="3" style="border-left: 0px transparent;" class="text-right">
              <b>Total Charges</b>
            </td>
            <td class="text-right">${Math.round(parseFloat(t.finaltotal||0)).toFixed(2)}</td>
          </tr>
          
          <tr>
            <td colspan="2">Warranty</td>
            <td colspan="4" class="text-right">${t.warranty||""}</td>
          </tr>
          
          <tr>
            <td colspan="2">Delivery Terms</td>
            <td colspan="4" class="text-right">${t.delivery_terms||""}</td>
          </tr>
          
          <tr>
            <td colspan="2">Payment Terms</td>
            <td colspan="4" class="text-right">${t.payment_terms||""}</td>
          </tr>
          
          <tr>
            <td colspan="2">Other Details</td>
            <td colspan="4" class="text-right">${t.otherdetails||""}</td>
          </tr>
          
          <tr>
            <td colspan="2">Jurisdiction</td>
            <td colspan="4" class="text-right">${t.jurisdiction||""}</td>
          </tr>
          
          <tr>
            <td colspan="2">Billings & Shipping Address</td>
            <td colspan="4" class="text-right">${t.bill_and_consign_to||""}</td>
          </tr>
          
          <tr>
            <td colspan="2"></td>
            <td colspan="4" class="text-right">GST: ${a.gstno} PAN: ${a.panno}</td>
          </tr>
        </table>

        <!-- Notes -->
        <div style="margin-top: 20px;">
          <div><strong>Note:</strong></div>
          <div>1) Please Mention Our GSTIN No. ${a.gstno} in Invoice.</div>
          <div>2) This Work Order is Being sent to you in duplicate, a copy of Which may please be returned to us duly signed and stamped on each page in token of your acceptance Please Sign &return the Duplicate Copy of the order within three days as a token of your acceptance to the above terms & conditions. PO is deemed accepted for non-receipt of response from consultant within three days.</div>
        </div>

        <!-- Signature -->
        <div style="margin-top: 30px; display: flex; flex-direction: column; align-items: flex-end;">
          <div>For ${a.name}</div>
          ${t.status===1&&t.approved_by?`
            <div style="margin-top: 10px; text-align: center;">
              <div>Electronically signed by</div>
              <div>${t.approved_by_name||""}</div>
              ${t.approved_by_designation?`<div>Designation:${t.approved_by_designation}</div>`:""}
              <div>Date:${w(t.approved_on)}</div>
            </div>
          `:""}
          ${t.digitalsignUrl?`
            <div style="margin-top: 10px; margin-bottom: 5px;">
              <img src="${t.digitalsignUrl}" alt="Digital Signature" style="height: 60px; width: auto;" />
            </div>
          `:""}
          <div style="margin-top: ${t.digitalsignUrl?"5px":"20px"}; text-decoration: underline;">
            Authorised Signatory
          </div>
        </div>

        <!-- Footer Contact Info -->
        <div style="margin-top: 40px; text-align: center; font-size: 11px; font-weight: bold;">
          ${a.address.full_address} Ph. ${a.contact.phone}<br>
          Email : ${a.contact.email}, Web: ${a.contact.website?a.contact.website.replace("http://","").replace("https://",""):""}, CIN-${a.cin_no}
        </div>
      </body>
      </html>
    `},W=async()=>{if(h)try{const t=D(),o=window.open("","_blank");o.document.write(t),o.document.close(),setTimeout(()=>{o.print()},1e3)}catch(t){console.error("Error generating PDF:",t),R.error("Failed to generate PDF")}};return T?s.jsx(v,{title:"Export Purchase Order to PDF",children:s.jsxs("div",{className:"flex h-[60vh] items-center justify-center text-gray-600",children:[s.jsxs("svg",{className:"animate-spin h-6 w-6 mr-2 text-blue-600",viewBox:"0 0 24 24",children:[s.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),s.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"})]}),"Loading Purchase Order Data..."]})}):O?s.jsx(v,{title:"Export Purchase Order to PDF",children:s.jsxs("div",{className:"flex h-[60vh] flex-col items-center justify-center",children:[s.jsx("div",{className:"text-center mb-4",children:s.jsxs("div",{className:"text-red-600",children:["Error: ",O]})}),s.jsx(P,{variant:"outline",onClick:()=>N(`/dashboards/inventory/purchase-order/view-full-purchase-order?hakuna=${m}`),children:"Go Back"})]})}):h?s.jsxs(v,{title:`Export ${h.purchaseOrder.ordertype==="WO"?"Work Order":"Purchase Order"} to PDF`,children:[s.jsx("div",{className:"transition-content w-full px-[var(--margin-x)] pb-5 pt-4",children:s.jsxs(z,{className:"relative flex flex-col p-6",children:[s.jsxs("div",{className:"flex items-center justify-between border-b border-gray-200 pb-4 dark:border-dark-500",children:[s.jsxs("h2",{className:"text-xl font-semibold text-gray-800 dark:text-dark-50",children:[h.purchaseOrder.ordertype==="WO"?"Work Order":"Purchase Order"," PDF Preview"]}),s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsx(P,{variant:"outline",onClick:()=>N(`/dashboards/inventory/purchase-order/view-full-purchase-order?hakuna=${m}`),className:"h-9 px-4 text-sm",children:"<< Back"}),s.jsx(P,{onClick:W,variant:"filled",color:"primary",className:"h-9 px-4 text-sm",children:"Download PDF"})]})]}),s.jsxs("div",{className:"mt-6 mb-4 flex justify-between items-center text-sm",children:[s.jsxs("div",{className:"text-gray-600 dark:text-gray-400",children:[s.jsxs("strong",{children:[h.purchaseOrder.ordertype==="WO"?"Work Order":"Purchase Order",":"]})," ",h.purchaseOrder.po_number]}),s.jsxs("div",{className:"text-gray-600 dark:text-gray-400",children:[s.jsx("strong",{children:"Customer:"})," ",h.customer.company]})]}),s.jsx("div",{className:"border border-gray-300 rounded p-4 bg-gray-50 overflow-hidden flex justify-center",children:s.jsx("div",{dangerouslySetInnerHTML:{__html:D()},style:{transform:"scale(0.8)",transformOrigin:"top center",width:"125%",height:"auto"}})})]})}),s.jsx("style",{children:`
        .container {
          max-width: 1200px;
        }

        .btn {
          padding: 8px 16px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-weight: 500;
          transition: background-color 0.2s;
        }

        .btn:hover {
          opacity: 0.9;
        }

        @media print {
          body {
            margin: 0;
            padding: 0;
          }
          
          .container {
            max-width: none;
            padding: 0;
          }
          
          .bg-white,
          .shadow-lg,
          .rounded-lg,
          .p-6 {
            box-shadow: none;
            border-radius: 0;
            padding: 0;
          }
          
          button {
            display: none;
          }
        }
      `})]}):s.jsx(v,{title:"Export Purchase Order to PDF",children:s.jsx("div",{className:"flex h-[60vh] items-center justify-center text-gray-600",children:"No data available"})})}export{et as default};
